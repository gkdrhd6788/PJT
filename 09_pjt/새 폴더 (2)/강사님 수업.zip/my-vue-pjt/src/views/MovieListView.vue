<template>
    <div>
        MovieList
    </div>
</template>

<script setup>

</script>

<style scoped>

</style>